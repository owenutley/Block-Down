import type { Metadata } from '@devvit/protos/lib/Types.js';
import type { Context } from './server-context.js';
export declare function getMetadata(): Readonly<Metadata> | undefined;
/**
 * Runs an async callback with the given Context. Code in the callback can use
 * `getContext()` to get the context. For testing.
 * @experimental
 * @param context The context to run the callback with
 * @param callback The callback to run
 */
export declare function runWithContext<T>(context: Context, callback: () => Promise<T>): Promise<T>;
export declare const context: Context;
//# sourceMappingURL=context.d.ts.map