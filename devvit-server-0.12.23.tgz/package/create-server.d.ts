import '@devvit/shared-types/shared/devvit-worker-global.js';
import type { IncomingMessage, Server, ServerOptions, ServerResponse } from 'node:http';
/**
 * Creates a new Devvit server. This implements the same API as Node.js's `createServer` function,
 * but we do not guarantee that this actually creates an HTTP server of any kind - it may be any
 * kind of server under the hood. However, it will behave like an HTTP server in terms of the API.
 */
export declare const createServer: <Request extends typeof IncomingMessage = typeof IncomingMessage, Response extends typeof ServerResponse = typeof ServerResponse>(optionsOrRequestListener?: ServerOptions<Request, Response> | ((req: InstanceType<Request>, res: InstanceType<Response> & {
    req: InstanceType<Request>;
}) => any), requestListener?: (req: InstanceType<Request>, res: InstanceType<Response> & {
    req: InstanceType<Request>;
}) => any) => Server<Request, Response>;
declare global {
    namespace globalThis {
        var enableWebbitBundlingHack: boolean;
    }
}
//# sourceMappingURL=create-server.d.ts.map