import { AsyncLocalStorage } from 'node:async_hooks';
let requestContextStorage;
try {
    requestContextStorage = new AsyncLocalStorage();
}
catch {
    // Hack: workaround inclusion in Blocks client builds.
}
/**
 * Gets the current Context. This is set by the server when handling a request. If there is no
 * context, this will throw an error.
 * @returns The current Context.
 * @throws Error Will throw an error if there is no context.
 */
function getContext() {
    const ctx = requestContextStorage.getStore();
    if (!ctx) {
        throw new Error('No context found. Are you calling `createServer` Is this code running as part of a server request?');
    }
    return ctx;
}
export function getMetadata() {
    const ctx = requestContextStorage.getStore();
    if (!ctx) {
        return undefined;
    }
    return ctx.metadata;
}
/**
 * Runs an async callback with the given Context. Code in the callback can use
 * `getContext()` to get the context. For testing.
 * @experimental
 * @param context The context to run the callback with
 * @param callback The callback to run
 */
export async function runWithContext(context, callback) {
    return requestContextStorage.run(context, callback);
}
export const context = new Proxy({}, {
    get: (_target, prop) => {
        const context = getContext();
        return context[prop];
    },
    // The following two methods set up the Proxy to behave like a normal object when iterating over keys or
    // checking if a property exists. (This helps ensure tests pass too.)
    ownKeys() {
        return Object.keys(getContext());
    },
    getOwnPropertyDescriptor(_target, key) {
        return { enumerable: true, configurable: true, value: getContext()[key] };
    },
});
/**
 * Save a value to the cache associated with this context/request. Does not persist past this
 * request's lifespan. This can store complex objects, not just JSON-able values, if necessary!
 * @internal - External devs should use @devvit/cache or @devvit/redis for this.
 * @param key Key to store the value in
 * @param value Value to store
 */
export function setContextCache(key, value) {
    const context = getContext();
    if (!context.cache) {
        context.cache = {};
    }
    context.cache[key] = value;
}
/**
 * Gets a value from the cache associated with this context/request.
 * @internal - External devs should use @devvit/cache or @devvit/redis for this.
 * @param key Key to get the value of
 * @return The value retrieved, or `undefined` if no value has been saved
 */
export function getContextCache(key) {
    const context = getContext();
    if (!context.cache) {
        return undefined;
    }
    return context.cache[key];
}
