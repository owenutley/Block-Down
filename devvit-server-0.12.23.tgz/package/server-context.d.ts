import type { Metadata } from '@devvit/protos/lib/Types.js';
import type { BaseContext } from '@devvit/shared';
/** Devvit server context for the lifetime of a request. */
export type Context = BaseContext & {
    metadata: Metadata;
};
/** Designed to be compatible with IncomingHttpHeaders and any KV. */
type Headers = {
    [header: string]: string | string[] | undefined;
};
/** Constructs a new Context. */
export declare let Context: (headers: Readonly<Headers>) => Context;
/**
 * Overwrite the context provider for test.
 * @experimental
 */
export declare function setContext(fn: typeof Context): void;
export {};
//# sourceMappingURL=server-context.d.ts.map