import type { ScheduledCronJob, ScheduledCronJobOptions, ScheduledJob, ScheduledJobOptions } from './types/scheduler.js';
/**
 * The Scheduler client lets you schedule new jobs or cancel existing jobs.
 * You must have the `scheduler` enabled in `Devvit.configure` to use this client.
 */
export declare class SchedulerClient {
    #private;
    /**
     * Schedule a new job to run at a specific time or on a cron schedule
     * @param job The job to schedule
     * @returns {} The id of the scheduled job
     */
    runJob(job: ScheduledJobOptions | ScheduledCronJobOptions): Promise<string>;
    /**
     * Cancel a scheduled job
     * @param jobId The id of the job to cancel
     */
    cancelJob(jobId: string): Promise<void>;
    /**
     * Gets the list of all scheduled jobs.
     */
    listJobs(): Promise<(ScheduledJob | ScheduledCronJob)[]>;
}
//# sourceMappingURL=SchedulerClient.d.ts.map