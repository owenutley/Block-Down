import type { JsonObject } from '@devvit/shared';
export type ScheduledJob = {
    /** ID of the scheduled job. Use this with scheduler.cancelJob to cancel the job. */
    id: string;
    /** The name of the scheduled job type */
    name: string;
    /** Additional data passed in by the scheduler client */
    data: JsonObject | undefined;
    /** The Date of when this job should run */
    runAt: Date;
};
export type ScheduledCronJob = {
    /** ID of the scheduled job. Use this with scheduler.cancelJob to cancel the job. */
    id: string;
    /** The name of the scheduled job type */
    name: string;
    /** Additional data passed in by the scheduler client */
    data?: JsonObject | undefined;
    /** The cron string of when this job should run */
    cron: string;
};
export type ScheduledJobOptions<T extends JsonObject | undefined = JsonObject | undefined> = {
    /** The name of the scheduled job type */
    name: string;
    /** Additional data passed in by the scheduler client */
    data?: T;
    /** The Date of when this job should run */
    runAt: Date;
};
export type ScheduledCronJobOptions<T extends JsonObject | undefined = JsonObject | undefined> = {
    /** The name of the scheduled job type */
    name: string;
    /** Additional data passed in by the scheduler client */
    data?: T;
    /** The cron string of when this job should run */
    cron: string;
};
/**
 * Schedule a new job to run at a specific time or on a cron schedule
 * @param job The job to schedule
 * @returns {string} The id of the scheduled job
 */
export type RunJob<Data extends JsonObject | undefined> = (job: ScheduledJobOptions<Data> | ScheduledCronJobOptions<Data>) => Promise<string>;
/**
 * Cancel a scheduled job
 * @param jobId The id of the job to cancel
 */
export type CancelJob = (jobId: string) => Promise<void>;
export type ScheduledJobEvent<T extends JsonObject | undefined> = {
    /** The name of the scheduled job */
    name: string;
    /** Additional data passed in by the scheduler client */
    data: T;
};
export type ScheduledJobHandler<Data extends JsonObject | undefined = JsonObject | undefined> = (event: ScheduledJobEvent<Data>) => void | Promise<void>;
export type ScheduledJobType<Data extends JsonObject | undefined> = {
    /** The name of the scheduled job type */
    name: string;
    /** The function that will be called when the job is scheduled to run */
    onRun: ScheduledJobHandler<Data>;
};
/** The body of the request sent when a scheduled task is run.*/
export type TaskRequest<Data extends JsonObject | undefined = JsonObject | undefined> = {
    /** The name of the scheduled task being run */
    name: string;
    /**
     * If any data was provided when the task was scheduled, it's passed along here. In the case of
     * cronjobs, this will be the value specified in `devvit.json`.
     */
    data: Data;
};
/**
 * The response expected from the endpoint called when a scheduled task is run. Note that this
 * is currently empty, but may be extended in the future.
 */
export type TaskResponse = {};
//# sourceMappingURL=scheduler.d.ts.map