var __classPrivateFieldGet = (this && this.__classPrivateFieldGet) || function (receiver, state, kind, f) {
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
    return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
};
var _SchedulerClient_instances, _SchedulerClient_metadata_get, _SchedulerClient_plugin_get;
// eslint-disable-next-line no-restricted-imports
import { SchedulerDefinition } from '@devvit/protos';
import { context } from '@devvit/server';
import { assertNonNull } from '@devvit/shared-types/NonNull.js';
import { getDevvitConfig } from '@devvit/shared-types/server/get-devvit-config.js';
/**
 * The Scheduler client lets you schedule new jobs or cancel existing jobs.
 * You must have the `scheduler` enabled in `Devvit.configure` to use this client.
 */
export class SchedulerClient {
    constructor() {
        _SchedulerClient_instances.add(this);
    }
    /**
     * Schedule a new job to run at a specific time or on a cron schedule
     * @param job The job to schedule
     * @returns {} The id of the scheduled job
     */
    async runJob(job) {
        const response = await __classPrivateFieldGet(this, _SchedulerClient_instances, "a", _SchedulerClient_plugin_get).Schedule({
            action: { type: job.name, data: job.data },
            cron: 'cron' in job ? job.cron : undefined,
            when: 'runAt' in job ? job.runAt : undefined,
        }, __classPrivateFieldGet(this, _SchedulerClient_instances, "a", _SchedulerClient_metadata_get));
        return response.id;
    }
    /**
     * Cancel a scheduled job
     * @param jobId The id of the job to cancel
     */
    async cancelJob(jobId) {
        await __classPrivateFieldGet(this, _SchedulerClient_instances, "a", _SchedulerClient_plugin_get).Cancel({ id: jobId }, __classPrivateFieldGet(this, _SchedulerClient_instances, "a", _SchedulerClient_metadata_get));
    }
    /**
     * Gets the list of all scheduled jobs.
     */
    async listJobs() {
        const response = await __classPrivateFieldGet(this, _SchedulerClient_instances, "a", _SchedulerClient_plugin_get).List(
        /**
         * after and before are required for this API to work
         * so we hardcode after to Unix epoch and before to 10 years from now
         * https://reddit.atlassian.net/browse/DX-3060
         */
        {
            after: new Date(0),
            before: new Date(Date.now() + 10 * 365 * 86400 * 1000),
        }, __classPrivateFieldGet(this, _SchedulerClient_instances, "a", _SchedulerClient_metadata_get));
        return response.actions.map((action) => {
            assertNonNull(action.request?.action, 'Scheduled job is malformed');
            if ('when' in action.request && action.request.when != null) {
                return {
                    id: action.id,
                    name: action.request.action.type,
                    runAt: action.request.when,
                    data: action.request.action.data,
                };
            }
            return {
                id: action.id,
                name: action.request.action.type,
                cron: action.request.cron ?? '',
                data: action.request.action.data,
            };
        });
    }
}
_SchedulerClient_instances = new WeakSet(), _SchedulerClient_metadata_get = function _SchedulerClient_metadata_get() {
    return context.metadata;
}, _SchedulerClient_plugin_get = function _SchedulerClient_plugin_get() {
    return getDevvitConfig().use(SchedulerDefinition);
};
