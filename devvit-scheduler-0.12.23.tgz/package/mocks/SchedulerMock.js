import { randomUUID } from 'node:crypto';
export class SchedulerPluginMock {
    constructor(store) {
        this._store = store;
    }
    async Schedule(request, _metadata) {
        const id = randomUUID();
        this._store.set(id, request);
        return { id };
    }
    async Cancel(request, _metadata) {
        this._store.delete(request.id);
        return {};
    }
    async List(request, _metadata) {
        const actions = [];
        for (const [id, actionRequest] of this._store.entries()) {
            let include = true;
            // Filter by before/after if provided and if the action has a specific time
            if (actionRequest.when) {
                if (request.after && actionRequest.when < request.after) {
                    include = false;
                }
                if (request.before && actionRequest.when > request.before) {
                    include = false;
                }
            }
            if (include) {
                actions.push({ id, request: actionRequest });
            }
        }
        return { actions };
    }
}
/**
 * A mock that provides helpful methods and an in-memory store on top of the `SchedulerPluginMock`.
 */
export class SchedulerMock {
    constructor() {
        this._store = new Map();
        this.plugin = new SchedulerPluginMock(this._store);
    }
    /**
     * Returns all scheduled actions.
     *
     * @returns An array of objects containing the id and the request of the scheduled actions.
     */
    getScheduledActions() {
        return Array.from(this._store.entries()).map(([id, request]) => ({ id, request }));
    }
    /**
     * Clears all scheduled actions.
     */
    clear() {
        this._store.clear();
    }
}
