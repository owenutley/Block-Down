import type { Empty } from '@devvit/protos/json/google/protobuf/empty.js';
import type { Metadata } from '@devvit/protos/lib/Types.js';
import type { CancelActionRequest, ListActionRequest, ListActionResponse, ScheduledActionRequest, ScheduledActionResponse, Scheduler } from '@devvit/protos/types/devvit/plugin/scheduler/scheduler.js';
import type { PluginMock } from '@devvit/shared-types/test/index.js';
type JobId = string;
export declare class SchedulerPluginMock implements Scheduler {
    private readonly _store;
    constructor(store: Map<JobId, ScheduledActionRequest>);
    Schedule(request: ScheduledActionRequest, _metadata?: Metadata): Promise<ScheduledActionResponse>;
    Cancel(request: CancelActionRequest, _metadata?: Metadata): Promise<Empty>;
    List(request: ListActionRequest, _metadata?: Metadata): Promise<ListActionResponse>;
}
/**
 * A mock that provides helpful methods and an in-memory store on top of the `SchedulerPluginMock`.
 */
export declare class SchedulerMock implements PluginMock<Scheduler> {
    readonly plugin: SchedulerPluginMock;
    private readonly _store;
    constructor();
    /**
     * Returns all scheduled actions.
     *
     * @returns An array of objects containing the id and the request of the scheduled actions.
     */
    getScheduledActions(): {
        id: JobId;
        request: ScheduledActionRequest;
    }[];
    /**
     * Clears all scheduled actions.
     */
    clear(): void;
}
export {};
//# sourceMappingURL=SchedulerMock.d.ts.map